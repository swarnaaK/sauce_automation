import pytest


@pytest.mark.usefixtures("setup")
class baseclass():
    pass